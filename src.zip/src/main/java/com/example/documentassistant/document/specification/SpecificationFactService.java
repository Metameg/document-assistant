package com.example.documentassistant.document.specification;

import com.example.documentassistant.document.catalog.DocumentCatalogProperties;
import com.example.documentassistant.document.model.DocumentElement;
import com.example.documentassistant.document.model.ProcessedDocument;
import org.springframework.stereotype.Service;
import tools.jackson.databind.json.JsonMapper;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

@Service
public class SpecificationFactService {

  private final DocumentCatalogProperties catalogProperties;
  private final JsonMapper mapper;

  public SpecificationFactService(
      DocumentCatalogProperties catalogProperties,
      JsonMapper mapper) {
    this.catalogProperties = catalogProperties;
    this.mapper = mapper;
  }

  public List<SpecificationFact> factsForModel(String modelNumber) {
    Path directory = catalogProperties.processedDirectory()
        .toAbsolutePath()
        .normalize();

    if (!Files.isDirectory(directory)) {
      throw new IllegalStateException(
          "Processed document directory does not exist: " + directory);
    }

    List<Path> files;
    try (var paths = Files.list(directory)) {
      files = paths
          .filter(Files::isRegularFile)
          .filter(path -> path.getFileName().toString()
              .toLowerCase(Locale.ROOT).endsWith(".json"))
          .sorted()
          .toList();
    } catch (IOException exception) {
      throw new UncheckedIOException(
          "Could not list processed documents", exception);
    }

    List<SpecificationFact> facts = new ArrayList<>();

    for (Path file : files) {
      ProcessedDocument document;
      try {
        document = mapper.readValue(
            Files.readString(file), ProcessedDocument.class);
      } catch (IOException exception) {
        throw new UncheckedIOException(
            "Could not read processed document: " + file, exception);
      }

      for (ProcessedDocument.Section section : document.sections()) {
        if (!section.modelNumbers().contains(modelNumber)) {
          continue;
        }

        for (DocumentElement element : section.elements()) {
          if (!(element instanceof DocumentElement.Specification specification)) {
            continue;
          }

          String value = specification.sharedValue() != null
              ? specification.sharedValue()
              : specification.valuesByModel().get(modelNumber);

          if (value == null) {
            continue;
          }

          facts.add(new SpecificationFact(
              modelNumber,
              document.documentId(),
              document.sourceFile(),
              document.revision().revision(),
              document.revision().publicationDate(),
              section.title(),
              specification.name(),
              value,
              specification.units(),
              specification.pageNumber(),
              specification.elementId()));
        }
      }
    }

    return List.copyOf(facts);
  }
}

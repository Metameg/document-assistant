package com.example.documentassistant.document.specification;

import java.util.List;

public record SpecificationFact(
    String modelNumber,
    String documentId,
    String sourceFile,
    String revision,
    String publicationDate,
    String section,
    String name,
    String value,
    List<String> units,
    int pageNumber,
    String sourceElementId) {

  public SpecificationFact {
    units = List.copyOf(units);
  }
}

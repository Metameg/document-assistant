package com.example.documentassistant.retrieval;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects;

@Service
public class KeywordChunkSearchService {

  private final JdbcTemplate jdbcTemplate;
  private final String qualifiedTable;

  public KeywordChunkSearchService(
      JdbcTemplate jdbcTemplate,
      @Value("${spring.ai.vectorstore.pgvector.schema-name:public}") String schemaName,
      @Value("${spring.ai.vectorstore.pgvector.table-name:vector_store}") String tableName) {

    this.jdbcTemplate = Objects.requireNonNull(jdbcTemplate);

    // Identifiers cannot be JDBC parameters, so validate configuration
    // before placing these two names into the SQL statement.
    if (!schemaName.matches("[A-Za-z_][A-Za-z0-9_]*")
        || !tableName.matches("[A-Za-z_][A-Za-z0-9_]*")) {
      throw new IllegalArgumentException(
          "Invalid pgvector schema or table name");
    }

    this.qualifiedTable = schemaName + "." + tableName;
  }

  public List<KeywordCandidate> search(String query, int topK) {
    if (query == null || query.isBlank()) {
      throw new IllegalArgumentException("query must not be blank");
    }
    if (topK < 1 || topK > 100) {
      throw new IllegalArgumentException("topK must be between 1 and 100");
    }

    String sql = """
        WITH terms AS (
          SELECT replace(
            plainto_tsquery('english', ?)::text,
            ' & ',
            ' | '
          )::tsquery AS search_terms
        ),
        chunks AS (
          SELECT
            v.content,
            v.metadata,
            setweight(
              to_tsvector(
                'english',
                coalesce(v.metadata->>'section', '')
              ),
              'A'
            ) ||
            setweight(
              to_tsvector('english', coalesce(v.content, '')),
              'D'
            ) AS search_text
          FROM %s v
        )
        SELECT
          ts_rank_cd(c.search_text, t.search_terms)
            AS keyword_score,
          c.metadata->>'documentId' AS document_id,
          c.metadata->>'sourceFile' AS source_file,
          c.metadata->>'section' AS section,
          (c.metadata->>'chunkIndex')::integer AS chunk_index,
          c.metadata->>'modelNumbers' AS model_numbers,
          c.content
        FROM chunks c
        CROSS JOIN terms t
        WHERE c.search_text @@ t.search_terms
        ORDER BY
          keyword_score DESC,
          document_id,
          chunk_index
        LIMIT ?
        """.formatted(qualifiedTable);

    return jdbcTemplate.query(
        sql,
        statement -> {
          statement.setString(1, query.trim());
          statement.setInt(2, topK);
        },
        (result, rowNumber) -> new KeywordCandidate(
            result.getDouble("keyword_score"),
            result.getString("document_id"),
            result.getString("source_file"),
            result.getString("section"),
            result.getInt("chunk_index"),
            result.getString("model_numbers"),
            result.getString("content")));
  }

  public record KeywordCandidate(
      double keywordScore,
      String documentId,
      String sourceFile,
      String section,
      int chunkIndex,
      String modelNumbers,
      String text) {
  }
}

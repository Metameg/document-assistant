package com.example.documentassistant.retrieval;

import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.prompt.ChatOptions;
import org.springframework.ai.rag.Query;
import org.springframework.ai.rag.preretrieval.query.expansion.MultiQueryExpander;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RetrievalQueryExpander {

  private final MultiQueryExpander expander;

  public RetrievalQueryExpander(ChatClient.Builder builder) {
    this.expander = MultiQueryExpander.builder()
        .chatClientBuilder(
            builder.defaultOptions(
                ChatOptions.builder()
                    .temperature(0.0)))
        .numberOfQueries(3)
        .includeOriginal(true)
        .build();
  }

  public MultiQueryExpander queryExpander() {
    return expander;
  }

  public ExpansionResult expand(String question) {
    if (question == null || question.isBlank()) {
      throw new IllegalArgumentException(
          "question must not be blank");
    }

    String original = question.trim();

    List<String> searchQueries = expander
        .expand(new Query(original))
        .stream()
        .map(Query::text)
        .distinct()
        .toList();

    return new ExpansionResult(original, searchQueries);
  }

  public record ExpansionResult(
      String originalQuestion,
      List<String> searchQueries) {

    public ExpansionResult {
      searchQueries = List.copyOf(searchQueries);
    }
  }
}

package com.example.documentassistant.web;

import com.example.documentassistant.document.specification.SpecificationFact;
import com.example.documentassistant.document.specification.SpecificationFactService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/specifications")
public class SpecificationController {

  private final SpecificationFactService factService;

  public SpecificationController(SpecificationFactService factService) {
    this.factService = factService;
  }

  @GetMapping
  public List<SpecificationFact> forModel(
      @RequestParam String modelNumber) {

    if (modelNumber.isBlank()) {
      throw new ResponseStatusException(
          HttpStatus.BAD_REQUEST, "modelNumber must not be blank");
    }

    return factService.factsForModel(modelNumber);
  }
}

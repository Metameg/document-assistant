package com.example.documentassistant.web;

import com.example.documentassistant.retrieval.RetrievalQueryExpander;
import com.example.documentassistant.retrieval.RetrievalRequest;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/retrieval")
public class RetrievalExpansionController {

  private final RetrievalQueryExpander expander;

  public RetrievalExpansionController(
      RetrievalQueryExpander expander) {
    this.expander = expander;
  }

  @PostMapping("/expand")
  public RetrievalQueryExpander.ExpansionResult expand(
      @RequestBody RetrievalRequest request) {

    return expander.expand(request.query());
  }
}

package com.example.documentassistant.web;

import com.example.documentassistant.retrieval.KeywordChunkSearchService;
import com.example.documentassistant.retrieval.KeywordChunkSearchService.KeywordCandidate;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/retrieval")
public class KeywordRetrievalController {

  private final KeywordChunkSearchService keywordSearch;

  public KeywordRetrievalController(
      KeywordChunkSearchService keywordSearch) {
    this.keywordSearch = keywordSearch;
  }

  @GetMapping("/keyword")
  public List<KeywordCandidate> search(
      @RequestParam String query,
      @RequestParam(defaultValue = "20") int topK) {

    if (query.isBlank() || topK < 1 || topK > 100) {
      throw new ResponseStatusException(
          HttpStatus.BAD_REQUEST,
          "Provide a query and a topK between 1 and 100");
    }

    return keywordSearch.search(query, topK);
  }
}
